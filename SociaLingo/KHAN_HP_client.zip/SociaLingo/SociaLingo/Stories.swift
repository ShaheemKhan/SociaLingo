//
//  Comments.swift
//  SociaLingo
//
//  Created by Shaheem Khan on 2016-06-26.
//  Copyright © 2016 Shaheem Khan. All rights reserved.
//


import UIKit
import Localize_Swift


class Stories: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var tableView: UITableView!
    @IBOutlet var options: UISegmentedControl!

    var tableData: [String] = []
    var scoreData: [Int] = []
    var idData: [String] = []

    
    override func viewDidLoad() {
        
        self.title = "Your Stories".localized()
        let screenSize:CGRect = UIScreen.mainScreen().bounds
        
        let items = ["Writings".localized(), "Speeches".localized()]
        options = UISegmentedControl(items: items)
        options.selectedSegmentIndex = 0
        let frame = UIScreen.mainScreen().bounds
        options.frame = CGRectMake(frame.minX + 10, frame.minY + 50,
                                    frame.width - 20, frame.height*0.1)
        options.addTarget(self, action: #selector(Stories.changeType(_:)), forControlEvents: .ValueChanged)
        options.tintColor = UIColor(red: 140.0/255, green: 117.0/255, blue: 171.0/255, alpha: 1.0)
        self.view.addSubview(options)
        
        tableView = UITableView()
        tableView.frame = CGRectMake(0, (frame.minY + 50)+(frame.height*0.1), screenSize.width, (screenSize.height-((frame.minY + 50)+(frame.height*0.1))))
        tableView.delegate = self
        tableView.dataSource = self
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "cell")
        self.view.addSubview(self.tableView)
        
        retrieveStories(0)
        
        self.tableView.separatorStyle = .None
        self.tableView.registerNib(UINib(nibName: "StoriesTableViewCell", bundle: nil), forCellReuseIdentifier: "myCell")
        self.tableView.backgroundView = nil
        self.tableView.backgroundColor = UIColor(red: 75.0/255.0, green: 45.0/255.0, blue: 116.0/255.0, alpha: 1.0)
        self.tableView.rowHeight = 100
        super.viewDidLoad()

    }

    func retrieveStories(type :Int) {
        var dataBack: String = "";
        var request: NSMutableURLRequest
        if (type == 0) {
            request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/u/stories/writings")!)
        }
        else {
            request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/u/stories/speeches")!)
        }
        request.HTTPMethod = "POST"
        let defaults = NSUserDefaults.standardUserDefaults()
        let customAllowedSet =  NSCharacterSet(charactersInString:"+=\"#%/<>?@\\^`{|}").invertedSet
        let tk: String = defaults.objectForKey("token") as! String
        let escapedString: String! = tk.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
        let postString = "token=\(escapedString)"
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            if error != nil {
                print("error=\(error)")
                return
            }
            dataBack = NSString(data: data!, encoding: NSUTF8StringEncoding)! as String
            
            dispatch_async(dispatch_get_main_queue()) {
                let json: AnyObject? = dataBack.parseJSONString
                if (json != nil) {
                    print("Parsed JSON: \(json!.count)")
                    var num: Int = 0
                    for temp in json as! [[String: AnyObject]] {
                        num = num + 1
                        var name: String
                        var id: String
                        if (type == 0) {
                            name = (temp as NSDictionary)["data"] as! String
                        }
                        else {
                            name = "Sound File #\(num)"
                        }
                        let score = (temp as NSDictionary)["score"] as! Int
                        if (type == 0) {
                            id = (temp as NSDictionary)["writingPK"] as! String
                        }
                        else {
                            id = (temp as NSDictionary)["speakingPK"] as! String
                        }
                        self.tableData.append(name)
                        self.scoreData.append(score)
                        self.idData.append(id)
                    }
                    self.tableView.reloadData()
                }
            }
            
        }
        task.resume()
    }
    
    func changeType(sender: UISegmentedControl) {
        self.tableData.removeAll()
        self.scoreData.removeAll()
        self.idData.removeAll()
        self.tableView.reloadData()
        retrieveStories(sender.selectedSegmentIndex)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.tableData.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {

        let cell: StoriesTableViewCell = tableView.dequeueReusableCellWithIdentifier("myCell") as! StoriesTableViewCell
        
        cell.contentView.frame = CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height);
        cell.autoresizingMask = UIViewAutoresizing.FlexibleHeight
        cell.contentMode = UIViewContentMode.ScaleAspectFill
        cell.indentationLevel = 0;
        cell.shouldIndentWhileEditing = false;
        cell.textL?.text = self.tableData[indexPath.row]
        cell.scoreL?.text = "\(self.scoreData[indexPath.row])"
        if (self.scoreData[indexPath.row] > 0) {
            cell.agree?.text = "▲"
            cell.disagree?.text = "▽"
        }
        else if (self.scoreData[indexPath.row] == 0){
            cell.agree?.text = "△"
            cell.disagree?.text = "▽"
        }
        else {
            cell.agree?.text = "△"
            cell.disagree?.text = "▼"
        }
        cell.backgroundColor = self.view.backgroundColor
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("Row \(indexPath.row) selecteds \(self.idData[indexPath.row])")
        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Comments") as! Comments
        if (options.selectedSegmentIndex == 1) {
            secondViewController.type = 1
        }
        else {
            secondViewController.type = 0
        }
        secondViewController.id = idData[indexPath.row]
        secondViewController.writingText = tableData[indexPath.row]
        self.tableView.deselectRowAtIndexPath(indexPath, animated: false)
        self.navigationController?.pushViewController(secondViewController, animated: true)
    }
        
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}

