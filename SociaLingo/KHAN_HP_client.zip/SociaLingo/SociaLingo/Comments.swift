//
//  Comments.swift
//  SociaLingo
//
//  Created by Shaheem Khan on 2016-06-26.
//  Copyright © 2016 Shaheem Khan. All rights reserved.
//


import UIKit
import Localize_Swift

class Comments: UIViewController, UITableViewDelegate, UITableViewDataSource,  AVAudioPlayerDelegate, AVAudioRecorderDelegate {
    
    @IBOutlet var tableView: UITableView!
    @IBOutlet var textBox: UITextView!
    @IBOutlet var option: UISegmentedControl!
    
    var audioPlayer: AVAudioPlayer!
    var soundFile: NSData!
    var pauseButton: UIButton!
    var playButton: UIButton!
    var stopButton: UIButton!
    var bar: UIProgressView!
    var timeLabel: UILabel!
    var secondsTimer: NSTimer!
    var curTime: Int!
    
    var id: String = ""
    var writingText = ""
    var tableData: [String] = []
    var type: Int = 0
    
    override func viewDidLoad() {
        
        
        
        self.title = "Comments".localized()
        if (type != 0) {
            textBox.hidden = true
            curTime = 0
            
            let screenSize: CGRect = UIScreen.mainScreen().bounds
            let screenWidth = screenSize.width
            let screenHeight = screenSize.height
            
            pauseButton = UIButton(type: .Custom)
            pauseButton.setTitle("Pause".localized(), forState: .Normal)
            pauseButton.frame = CGRectMake(((screenWidth/2) - 35.0) - 70.0, screenHeight/4, 70, 40.0)
            pauseButton.enabled = false
            pauseButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
            pauseButton.setTitleColor(UIColor.grayColor(), forState: .Disabled)
            pauseButton.addTarget(self, action: #selector(self.pauseFunc), forControlEvents: UIControlEvents.TouchDown)
            self.view.addSubview(pauseButton)
            
            playButton = UIButton(type: .Custom)
            playButton.setTitle("Play".localized(), forState: .Normal)
            playButton.frame = CGRectMake(((screenWidth/2) - 35.0), screenHeight/4, 70, 40.0)
            playButton.enabled = false
            playButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
            playButton.setTitleColor(UIColor.grayColor(), forState: .Disabled)
            playButton.addTarget(self, action: #selector(self.playFunc), forControlEvents: UIControlEvents.TouchDown)
            self.view.addSubview(playButton)
            
            stopButton = UIButton(type: .Custom)
            stopButton.setTitle("Stop".localized(), forState: .Normal)
            stopButton.frame = CGRectMake(((screenWidth/2) - 35.0) + 70.0, screenHeight/4, 70, 40.0)
            stopButton.enabled = false
            stopButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
            stopButton.setTitleColor(UIColor.grayColor(), forState: .Disabled)
            stopButton.addTarget(self, action: #selector(self.stopFunc), forControlEvents: UIControlEvents.TouchDown)
            self.view.addSubview(stopButton)
            
            bar = UIProgressView()
            bar.frame = CGRectMake((screenWidth/2) - 105, (screenHeight/4) + 40.0, 210, 20)
            bar.setProgress(0/0, animated: false)
            bar.tintColor = UIColor.whiteColor()
            self.view.addSubview(bar)
            
            timeLabel = UILabel()
            timeLabel.text = "00:00/01:30"
            timeLabel.textColor = UIColor.whiteColor()
            timeLabel.textAlignment = NSTextAlignment.Right
            timeLabel.frame = CGRectMake(((screenWidth/2)-105), (screenHeight/4) + 60.0, 210.0, 20.0)
            self.view.addSubview(timeLabel)
            
            var dataBack: String = "";
            let request: NSMutableURLRequest = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/s/retrieve/sound")!)
            request.HTTPMethod = "POST"
            let postString = "id=\(id)"
            request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
            let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
                data, response, error in
                if error != nil {
                    print("error=\(error)")
                    return
                }
                dataBack = NSString(data: data!, encoding: NSUTF8StringEncoding)! as String
                
                dispatch_async(dispatch_get_main_queue()) {
                    let soundData: NSData! = NSData(base64EncodedString: dataBack, options:   NSDataBase64DecodingOptions(rawValue: 0))
                    self.soundFile = soundData
                    self.playButton.enabled = true
                }
                
            }
            task.resume()
        }
        
        textBox.scrollEnabled = false
        textBox.text = writingText
        self.tableView.separatorStyle = .None
        option.setTitle("Upvotes", forSegmentAtIndex: 0)
        option.setTitle("Downvotes", forSegmentAtIndex: 1)
        let titleTextAttributes = [NSForegroundColorAttributeName: UIColor.whiteColor()]
        UISegmentedControl.appearance().setTitleTextAttributes(titleTextAttributes, forState: .Selected)
        updateTableData("upvote")
        self.automaticallyAdjustsScrollViewInsets = false
        self.tableView.backgroundView = nil
        self.tableView.backgroundColor = self.textBox.backgroundColor
        self.tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        super.viewDidLoad()
    }
    
    func onTick() {
        let totalTime: Int = Int(audioPlayer.duration)
        curTime = curTime + 1;
        if (curTime == totalTime) {
            secondsTimer.invalidate()
            curTime = 0;
            playButton.enabled = true
            pauseButton.enabled = false
            stopButton.enabled = false
            bar.setProgress(Float(curTime)/Float(audioPlayer.duration), animated: false)
        }
        else {
            bar.setProgress(Float(curTime)/Float(audioPlayer.duration), animated: true)
        }
        self.timeLabel.text = self.getFormattedTime(Int(audioPlayer.duration))
    }
    
    func getFormattedTime(totalTime: Int)->String {
        let tm: Int = (totalTime / 60) % 60
        let ts: Int = totalTime % 60
        let cm: Int = (curTime / 60) % 60;
        let cs: Int = curTime % 60;
        return String.localizedStringWithFormat("%02u:%02u/%02u:%02u", cm, cs, tm, ts)
    }
    
    func playFunc() {
        if (audioPlayer != nil && audioPlayer.rate == 0) {
            audioPlayer.play()
            secondsTimer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: #selector(Comments.onTick), userInfo: nil, repeats: true)
        }
        else {
            do {
                try audioPlayer = AVAudioPlayer(data: soundFile)
            }
            catch {
                print("error")
            }
            
            audioPlayer.delegate = self
            let totalTime: Int = Int(audioPlayer.duration)
            timeLabel.text =  self.getFormattedTime(totalTime)
            playButton.enabled = false
            pauseButton.enabled = true
            stopButton.enabled = true
            audioPlayer.play()
            if (secondsTimer != nil) {
                secondsTimer.invalidate()
            }
            secondsTimer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: #selector(Comments.onTick), userInfo: nil, repeats: true)
        }
    }
    
    func stopFunc() {
        audioPlayer.stop()
        secondsTimer.invalidate()
        curTime = 0
        playButton.enabled = true
        pauseButton.enabled = false
        stopButton.enabled = false
        bar.setProgress(Float(curTime)/Float(audioPlayer.duration), animated: false)
        timeLabel.text = self.getFormattedTime(Int(audioPlayer.duration))
    }
    
    func pauseFunc() {
        playButton.enabled = true
        pauseButton.enabled = false
        stopButton.enabled = false
        secondsTimer.invalidate()
        audioPlayer.pause()
    }
    
    func updateTableData(type: String) {
        self.tableData.removeAll()
        var dataBack: String = "";
        var request: NSMutableURLRequest
        if (self.type == 0) {
            request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/u/comments/writings")!)
        }
        else {
            request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/u/comments/speeches")!)
        }
        request.HTTPMethod = "POST"
        let postString = "id=\(id)&data=\(type)"
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            if error != nil {
                print("error=\(error)")
                return
            }
            dataBack = NSString(data: data!, encoding: NSUTF8StringEncoding)! as String
            
            dispatch_async(dispatch_get_main_queue()) {
                let json: AnyObject? = dataBack.parseJSONString
                if (json != nil) {
                    print("Parsed JSON: \(json!)")
                    for temp in json as! [[String: AnyObject]] {
                        let name = (temp as NSDictionary)["text"] as! String
                        self.tableData.append(name)
                    }
                }
                if (self.tableData.count == 0) {
                    self.tableData.append("No Comments".localized())
                }
                self.tableView.reloadData()
            }
            
        }
        task.resume()
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.tableData.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cellIdentifier = "Cell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier)! as UITableViewCell
        
        let row = indexPath.row
        cell.textLabel?.text = self.tableData[row]
        cell.textLabel?.textColor = UIColor.whiteColor()
        cell.backgroundColor = self.textBox.backgroundColor
        cell.textLabel?.font = UIFont.systemFontOfSize(9.0)
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("Row \(indexPath.row) selected")
    }
    
    @IBAction func indexChanged(sender:UISegmentedControl) {
        switch option.selectedSegmentIndex {
        case 0:
            updateTableData("upvote")
        case 1:
            updateTableData("downvote")
        default:
            break;
        }
    }
    
    override func viewDidAppear(animated: Bool) {
        textBox.scrollEnabled = true
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}

