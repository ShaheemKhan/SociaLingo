//
//  PractiseWriting.swift
//  SociaLingo
//
//  Created by Shaheem Khan on 2016-06-22.
//  Copyright © 2016 Shaheem Khan. All rights reserved.
//

import UIKit
import AVFoundation
import Localize_Swift

class PractiseSpeaking: UIViewController, AVAudioPlayerDelegate, AVAudioRecorderDelegate {
    
    var audioPlayer: AVAudioPlayer!
    var audioRecorder: AVAudioRecorder!
    var secondsTimer: NSTimer!
    var seconds: Int!
    var minutes: Int!
    @IBOutlet var playButton: UIButton!
    @IBOutlet var recordButton: UIButton!
    @IBOutlet var stopButton: UIButton!
    @IBOutlet var submitButton: UIButton!
    @IBOutlet var bar: UIProgressView!
    @IBOutlet var timeLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        bar.setProgress(0, animated: false)
        submitButton.setTitle("Submit".localized(), forState: .Normal)
        playButton.enabled = false
        submitButton.enabled = false
        stopButton.enabled = false

        recordButton.setTitle("Record".localized(), forState: .Disabled)
        playButton.setTitle("Play".localized(), forState: .Disabled)
        stopButton.setTitle("Stop".localized(), forState: .Disabled)
        submitButton.setTitle("Submit".localized(), forState: .Disabled)
        
        recordButton.setTitle("Record".localized(), forState: .Normal)
        playButton.setTitle("Play".localized(), forState: .Normal)
        stopButton.setTitle("Stop".localized(), forState: .Normal)
        submitButton.setTitle("Submit".localized(), forState: .Normal)
        
        recordButton.setTitleColor(UIColor.grayColor(), forState: .Disabled)
        playButton.setTitleColor(UIColor.grayColor(), forState: .Disabled)
        submitButton.setTitleColor(UIColor.grayColor(), forState: .Disabled)
        stopButton.setTitleColor(UIColor.grayColor(), forState: .Disabled)
        stopButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        submitButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        recordButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        playButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        let dirPaths =
            NSSearchPathForDirectoriesInDomains(.DocumentDirectory,
                                                .UserDomainMask, true)
        let docsDir = dirPaths[0]
        let soundFileURL = NSURL(fileURLWithPath:docsDir).URLByAppendingPathComponent("sound.acc")
        let recordSettings =
            [AVEncoderAudioQualityKey: AVAudioQuality.Min.rawValue,
             AVEncoderBitRateKey: 16,
             AVNumberOfChannelsKey: 2,
             AVSampleRateKey: 32000.0]
        
        seconds = 0
        minutes = 0
        
        
        do {
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(AVAudioSessionCategoryPlayAndRecord)
            try audioRecorder = AVAudioRecorder(URL: soundFileURL, settings: recordSettings as! [String : AnyObject])
            audioRecorder?.prepareToRecord()
        }
        catch {
            print("error")
        }
    }
    
    func updateSeconds() {
        seconds = seconds + 1
        if (seconds >= 60) {
            seconds = seconds - 60
            minutes = minutes + 1
        }
        if (minutes == 1 && seconds == 30) {
            secondsTimer.invalidate()
            stopAudio()
        }
        if (seconds < 10) {
            timeLabel.text = "\(minutes):0\(seconds)/1:30"
        }
        
        else {
            timeLabel.text = "\(minutes):\(seconds)/1:30"
        }
        let value: Float! = ((60.0 * Float(minutes)) + Float(seconds))/90.0
        bar.setProgress(value, animated: true)
        print("Seconds \(seconds) Minues \(minutes)")
    }
    
    @IBAction func recordAudio(sender: AnyObject) {
        if audioRecorder?.recording == false {
            playButton.enabled = false
            stopButton.enabled = true
            recordButton.enabled = false
            submitButton.enabled = false
            timeLabel.text = "0:00/1:30"
            if (secondsTimer != nil) {
                secondsTimer.invalidate()
            }
            secondsTimer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: #selector(PractiseSpeaking.updateSeconds), userInfo: nil, repeats: true)
            audioRecorder?.record()
        }
    }
    
    @IBAction func stopAudio() {
        stopButton.enabled = false
        playButton.enabled = true
        recordButton.enabled = true
        secondsTimer.invalidate()
        seconds = 0
        minutes = 0
        if (seconds < 10) {
            timeLabel.text = "\(minutes):0\(seconds)/1:30"
        }
            
        else {
            timeLabel.text = "\(minutes):\(seconds)/1:30"
        }
        let value: Float! = ((60.0 * Float(minutes)) + Float(seconds))/90.0
        bar.setProgress(value, animated: false)
        submitButton.enabled = true

        if audioRecorder?.recording == true {
            audioRecorder?.stop()
            
        } else {
            audioPlayer?.stop()
        }
    }
    
    @IBAction func playAudio(sender: AnyObject) {
        if audioRecorder?.recording == false {
            stopButton.enabled = true
            recordButton.enabled = false
            playButton.enabled = false
            submitButton.enabled = false
            do {
                try audioPlayer = AVAudioPlayer(contentsOfURL: (audioRecorder?.url)!)
                audioPlayer?.delegate = self
                audioPlayer?.play()
                timeLabel.text = "0:00/1:30"
                if (secondsTimer != nil) {
                    secondsTimer.invalidate()
                }
                secondsTimer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: #selector(PractiseSpeaking.updateSeconds), userInfo: nil, repeats: true)
            }
            catch {
                print("error")
            }

        }
    }
    

    @IBAction func submit(sender: AnyObject) {
        let dataValue: NSData! = NSData(contentsOfURL: (audioRecorder?.url)!)
        let stringValue: String! = dataValue.base64EncodedStringWithOptions(NSDataBase64EncodingOptions.EncodingEndLineWithLineFeed)
        print("Data \(dataValue.hashValue)")
        print("String \(stringValue.hashValue)")

        let request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/s/submit")!)
        request.HTTPMethod = "POST"
        let defaults = NSUserDefaults.standardUserDefaults()
        let tk:String! = defaults.objectForKey("token") as! String
        let customAllowedSet =  NSCharacterSet(charactersInString:"+=\"#%/<>?@\\^`{|}").invertedSet
        let escapedString = tk.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
        
        let tempNative:String! = defaults.objectForKey("nativeLanguage") as! String
        let tempSecond:String! = defaults.objectForKey("secondLanguage") as! String
        let nativeL: String! = tempNative.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
        let secondL: String! = tempSecond.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
        let postString = "token=\(escapedString!)&data=\(stringValue)&native=\(nativeL)&second=\(secondL)"
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            if error != nil {
                print("error=\(error)")
                return
            }
            let dataBack: String = NSString(data: data!, encoding: NSUTF8StringEncoding)! as String
            if(dataBack == "SUCCESS"){
                dispatch_async(dispatch_get_main_queue()) {
                    print("done " + dataBack)
                    self.navigationController?.popViewControllerAnimated(true)
                }
            }
            else {
                dispatch_async(dispatch_get_main_queue()) {
                    print("error " + dataBack)
                }
            }
        }
        task.resume()

        
    }
    
    func audioPlayerDidFinishPlaying(player: AVAudioPlayer, successfully flag: Bool) {
        stopAudio()
    }
    
    
    
}
