#import "DraggableViewSpeakingBackground.h"
#import "SociaLingo-Swift.h"


@implementation DraggableViewSpeakingBackground{
    NSInteger cardsLoadedIndex;
    NSMutableArray *loadedCards;
    int curTime;
}

static int MAX_BUFFER_SIZE = 2;
static int CARD_HEIGHT = 450;
static int CARD_WIDTH = 290;
static int voteType = 1;

@synthesize allCards;
@synthesize ids, titleText, sumbitText, soundData, audioPlayer, secondsTimer, infoLabel, infoText, pauseText, stopText, playText;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [super layoutSubviews];
        
        CGRect screenRect = [[UIScreen mainScreen] bounds];
        CARD_HEIGHT = screenRect.size.height - 96;
        CARD_WIDTH =  screenRect.size.width - 32;
        loadedCards = [[NSMutableArray alloc] init];
        allCards = [[NSMutableArray alloc] init];
        ids = [[NSMutableArray alloc] init];
        soundData = [[NSMutableArray alloc] init];
        cardsLoadedIndex = 0;
        curTime = 0;
        [self loadCards];
    }
    return self;
}

-(void)setupView {
    
}

-(DraggableSpeakingView *)createDraggableViewWithDataAtIndex:(NSInteger)index
{
    DraggableSpeakingView *draggableView = [[DraggableSpeakingView alloc]initWithFrame:CGRectMake(16, 80, CARD_WIDTH, CARD_HEIGHT)];
    
    [draggableView setTitles: stopText: pauseText: playText];
    [draggableView.playButton addTarget:self
                                 action:@selector(playFunc)
                       forControlEvents:UIControlEventTouchUpInside];
    [draggableView.stopButton addTarget:self
                                 action:@selector(stopFunc)
                       forControlEvents:UIControlEventTouchUpInside];
    [draggableView.pauseButton addTarget:self
                                 action:@selector(pauseFunc)
                       forControlEvents:UIControlEventTouchUpInside];
    draggableView.panGestureRecognizer.enabled = NO;
    draggableView.swipeLabel.enabled = NO;
    draggableView.delegate = self;
    
    
    return draggableView;
}

-(NSString*) getFormattedTime:(int)totalTime {
    NSUInteger tm = (totalTime / 60) % 60;
    NSUInteger ts = totalTime % 60;
    NSUInteger cm = (curTime / 60) % 60;
    NSUInteger cs = curTime % 60;
    return [NSString stringWithFormat:@"%02u:%02u/%02u:%02u", cm, cs, tm, ts];
}

-(void) playFunc {
    if (audioPlayer != nil && audioPlayer.rate == 0) {
        [audioPlayer play];
        secondsTimer = [NSTimer scheduledTimerWithTimeInterval: 1.0
                                                        target: self
                                                      selector:@selector(onTick)
                                                      userInfo: nil repeats:YES];
    }
    else {
        NSData *soundFile = [soundData objectAtIndex:0];
        audioPlayer = [[AVAudioPlayer alloc] initWithData:soundFile error: nil];
        audioPlayer.delegate = self;
        int totalTime = audioPlayer.duration;
        DraggableSpeakingView *draggableView = [loadedCards objectAtIndex:0];
        draggableView.timeLabel.text =  [self getFormattedTime: totalTime];
        draggableView.playButton.enabled = NO;
        draggableView.pauseButton.enabled = YES;
        draggableView.stopButton.enabled = YES;
        [audioPlayer play];
        if (secondsTimer != nil)
            [secondsTimer invalidate];
        secondsTimer = [NSTimer scheduledTimerWithTimeInterval: 1.0
                                                        target: self
                                                      selector:@selector(onTick)
                                                      userInfo: nil repeats:YES];
    }
}

-(void) stopFunc {
    [audioPlayer stop];
    [secondsTimer invalidate];
    curTime = 0;
    DraggableSpeakingView *draggableView = [loadedCards objectAtIndex:0];
    draggableView.playButton.enabled = YES;
    draggableView.pauseButton.enabled = NO;
    draggableView.stopButton.enabled = NO;
    [draggableView.bar setProgress:curTime/audioPlayer.duration animated:NO];
    draggableView.timeLabel.text =  [self getFormattedTime: audioPlayer.duration];
}

-(void) pauseFunc {
    DraggableSpeakingView *draggableView = [loadedCards objectAtIndex:0];
    draggableView.playButton.enabled = YES;
    draggableView.pauseButton.enabled = NO;
    draggableView.stopButton.enabled = NO;
    [secondsTimer invalidate];
    [audioPlayer pause];
}

- (void) onTick {
    DraggableSpeakingView *draggableView = [loadedCards objectAtIndex:0];
    int totalTime = audioPlayer.duration;
    curTime = curTime + 1;
    if (curTime == totalTime) {
        [secondsTimer invalidate];
        curTime = 0;
        draggableView.panGestureRecognizer.enabled = YES;
        draggableView.swipeLabel.enabled = YES;
        draggableView.playButton.enabled = YES;
        draggableView.pauseButton.enabled = NO;
        draggableView.stopButton.enabled = NO;
        [draggableView.bar setProgress:curTime/audioPlayer.duration animated:NO];
    }
    else {
        [draggableView.bar setProgress:curTime/audioPlayer.duration animated:YES];
    }
    draggableView.timeLabel.text =  [self getFormattedTime: audioPlayer.duration];
    
}

-(void)loadCards
{
    if([ids count] > 0) {
        NSInteger numLoadedCardsCap =(([ids count] > MAX_BUFFER_SIZE)?MAX_BUFFER_SIZE:[ids count]);
        //%%% if the buffer size is greater than the data size, there will be an array error, so this makes sure that doesn't happen
        
        //%%% loops through the exampleCardsLabels array to create a card for each label.  This should be customized by removing "exampleCardLabels" with your own array of data
        for (int i = 0; i<[ids count]; i++) {
            DraggableSpeakingView* newCard = [self createDraggableViewWithDataAtIndex:i];
            [allCards addObject:newCard];
            
            if (i<numLoadedCardsCap) {
                //%%% adds a small number of cards to be loaded
                [loadedCards addObject:newCard];
            }
        }
        
        //%%% displays the small number of loaded cards dictated by MAX_BUFFER_SIZE so that not all the cards
        // are showing at once and clogging a ton of data
        for (int i = 0; i<[loadedCards count]; i++) {
            if (i>0) {
                [self insertSubview:[loadedCards objectAtIndex:i] belowSubview:[loadedCards objectAtIndex:i-1]];
            } else {
                [self addSubview:[loadedCards objectAtIndex:i]];
            }
            cardsLoadedIndex++; //%%% we loaded a card into loaded cards, so we have to increment
        }
    }
}

-(void)cardSwipedLeft:(UIView *)card {
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:titleText
                                                    message:@""
                                                   delegate:self
                                          cancelButtonTitle:sumbitText
                                          otherButtonTitles:nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    [alert show];
    
    voteType = -1;
}

-(void)cardSwipedRight:(UIView *)card {
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:titleText
                                                    message:@""
                                                   delegate:self
                                          cancelButtonTitle:sumbitText
                                          otherButtonTitles:nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    [alert show];
    
    voteType = 1;
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSString *ip;
    if (voteType == 1) {
        ip = [NSString stringWithFormat: @"http://%@:8080/restful/rest/s/upvote", [Config ip] ];
    }
    else {
        ip = [NSString stringWithFormat:@"http://%@:8080/restful/rest/s/downvote", [Config ip] ];
    }
    NSURL *url = [NSURL URLWithString: ip];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setHTTPMethod:@"POST"];
    [request setURL:url];
    NSCharacterSet *customAllowedSet = [NSCharacterSet characterSetWithCharactersInString:@"+=\"#%/<>?@\\^`{|}"].invertedSet;
    NSString *token = [[NSUserDefaults standardUserDefaults] objectForKey: @"token"];
    NSString *wID =  [ids objectAtIndex:0];
    
    NSString *postString = [NSString stringWithFormat:@"id=%@&token=%@&data=%@", [wID stringByAddingPercentEncodingWithAllowedCharacters:customAllowedSet], [token stringByAddingPercentEncodingWithAllowedCharacters:customAllowedSet],[alertView textFieldAtIndex:0].text ];
    request.HTTPBody = [postString dataUsingEncoding:NSUTF8StringEncoding];
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithRequest:request
                completionHandler:^(NSData *data,
                                    NSURLResponse *response,
                                    NSError *error) {
                    NSLog(@"ids %@", [[NSString alloc] initWithData: data encoding:NSASCIIStringEncoding]);
                    
                    [soundData removeObjectAtIndex: 0];
                    [ids removeObjectAtIndex:0];
                    [loadedCards removeObjectAtIndex:0];
                }] resume];
    
 
    if (cardsLoadedIndex < [allCards count]) { //%%% if we haven't reached the end of all cards, put another into the loaded cards
        [loadedCards addObject:[allCards objectAtIndex:cardsLoadedIndex]];
        cardsLoadedIndex++;//%%% loaded a card, so have to increment count
        [self insertSubview:[loadedCards objectAtIndex:(MAX_BUFFER_SIZE-1)] belowSubview:[loadedCards objectAtIndex:(MAX_BUFFER_SIZE-2)]];
    }
    if ([ids count] == 1) { //%%% if we haven't reached the end of all cards, put another into the loaded cards
        infoLabel = [[UILabel alloc] init];
        infoLabel.text = infoText;
        infoLabel.textColor = [UIColor whiteColor];
        infoLabel.textAlignment = NSTextAlignmentCenter;
        CGFloat height = [UIScreen mainScreen].bounds.size.height;
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        infoLabel.frame = CGRectMake(((width-210.0)/2), ((height-20.0)/2),210,20);
        [self addSubview:infoLabel];
    }
    
}


@end