//
//  PractiseWriting.swift
//  SociaLingo
//
//  Created by Shaheem Khan on 2016-06-22.
//  Copyright © 2016 Shaheem Khan. All rights reserved.
//

import UIKit

class PractiseWriting: UIViewController,  UITextViewDelegate {
    
    @IBOutlet var submit: UIButton?
    @IBOutlet var codeTextView: UITextView!
    var placeholderLabel : UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        submit?.setTitle("Submit".localized(), forState: .Normal)
        codeTextView.delegate = self
        placeholderLabel = UILabel()
        placeholderLabel.text = "Enter text here...".localized()
        placeholderLabel.font = UIFont.italicSystemFontOfSize(codeTextView.font!.pointSize)
        placeholderLabel.sizeToFit()
        codeTextView.addSubview(placeholderLabel)
        placeholderLabel.frame.origin = CGPointMake(5, codeTextView.font!.pointSize / 2)
        placeholderLabel.textColor = UIColor(white: 0, alpha: 0.3)
        placeholderLabel.hidden = !codeTextView.text.isEmpty
        codeTextView.setContentOffset(CGPointZero, animated: true)
        setupKeyboardNotifications()
    }
    
    func setupKeyboardNotifications() {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(PractiseWriting.keyboardWasShown(_:)), name: UIKeyboardDidShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(PractiseWriting.keyboardWillBeHidden(_:)), name: UIKeyboardWillHideNotification, object: nil)
    }
    
    func keyboardWasShown(aNotification:NSNotification) {
        let info = aNotification.userInfo
        let infoNSValue = info![UIKeyboardFrameBeginUserInfoKey] as! NSValue
        let kbSize = infoNSValue.CGRectValue().size
        let contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0)
        codeTextView.contentInset = contentInsets
        codeTextView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeHidden(aNotification:NSNotification) {
        let contentInsets = UIEdgeInsetsZero
        codeTextView.contentInset = contentInsets
        codeTextView.scrollIndicatorInsets = contentInsets
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        codeTextView.resignFirstResponder()
        self.view.endEditing(true)
    }
    
    func textViewDidChange(textView: UITextView) {
        placeholderLabel.hidden = !textView.text.isEmpty
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func submit(sender: UIButton) {
        var dataBack: String = "";
        let request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/w/submit")!)
        request.HTTPMethod = "POST"
        let defaults = NSUserDefaults.standardUserDefaults()
        var text:String = codeTextView.text
        if (text == "") {
            text = "test"
        }
        
        let user = defaults.objectForKey("username") as! String
        let lan1 = defaults.objectForKey("nativeLanguage") as! String
        let lan2 = defaults.objectForKey("secondLanguage") as! String
        let enc = try! (text+"_"+user+"_"+lan1+"_"+lan2).aesEncrypt(Config.key())
        let customAllowedSet =  NSCharacterSet(charactersInString:"+=\"#%/<>?@\\^`{|}").invertedSet
        let escapedString = enc.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
        let postString = "data="+escapedString!
        let finalString = postString.dataUsingEncoding(NSUTF8StringEncoding)
        request.HTTPBody = finalString
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            if error != nil {
                print("error=\(error)")
                return
            }
            dataBack = NSString(data: data!, encoding: NSUTF8StringEncoding)! as String
            if(dataBack == "SUCCESS"){
                dispatch_async(dispatch_get_main_queue()) {
                    print("done " + dataBack)
                    self.navigationController?.popViewControllerAnimated(true)
                }
            }
            else {
                dispatch_async(dispatch_get_main_queue()) {
                    print("error " + dataBack)
                }
            }
        }
        if (text.characters.count > 1000) {
            let alert = UIAlertController(title: "Error", message: "You went beyond 1000 words!", preferredStyle: UIAlertControllerStyle.Alert);
            let OKAction = UIAlertAction(title: "OK", style: .Destructive) { (action:UIAlertAction!) in
            }
            alert.addAction(OKAction)
            presentViewController(alert, animated: false, completion: nil);
        }
        else {
            task.resume()
        }
        if (dataBack != "") {
            print("tes");
        }
    }
    
}
