#import <UIKit/UIKit.h>
#import "DraggableWritingView.h"

@interface DraggableViewWritingBackground : UIView <DraggableWritingViewDelegate, UIAlertViewDelegate>

-(void)cardSwipedLeft:(UIView *)card;
-(void)cardSwipedRight:(UIView *)card;
-(void)loadCards;

@property (retain,nonatomic)NSMutableArray* exampleCardLabels;
@property (retain,nonatomic)NSMutableArray* ids;
@property (retain,nonatomic)NSMutableArray* allCards;
@property (retain,nonatomic)NSString* titleText;
@property (retain,nonatomic)NSString* sumbitText;
@property (nonatomic,strong)UILabel* infoLabel;
@property (retain,nonatomic)NSString* infoText;


@end
