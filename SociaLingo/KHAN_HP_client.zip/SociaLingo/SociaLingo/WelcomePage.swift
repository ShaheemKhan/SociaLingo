//
//  WelcomePage.swift
//  SociaLingo
//
//  Created by Shaheem Khan on 2016-06-04.
//  Copyright © 2016 Shaheem Khan. All rights reserved.
//

import UIKit

class WelcomePage: UIViewController {
    
    @IBOutlet var username: UIButton?
    @IBOutlet var practiseButton: UIButton?
    @IBOutlet var assistButton: UIButton?
    @IBOutlet var levelLabel: UIButton?
    @IBOutlet var storiesButton: UIButton?
    @IBOutlet var expLabel: UIButton?
    @IBOutlet var bar: UIProgressView?
    var levelValue: String? = " 0"

    
    override func viewDidLoad() {
        self.view.layer.removeAllAnimations();
        self.navigationController?.navigationBarHidden = true
        let defaults = NSUserDefaults.standardUserDefaults()
        print (defaults.objectForKey("nativeLanguage"))

   
        username?.setTitle(defaults.objectForKey("username") as? String, forState: .Normal)
        setText()
        super.viewDidLoad()

    }
    
    func setText(){
        
        let defaults = NSUserDefaults.standardUserDefaults()
        
        if let nativeL = defaults.objectForKey("nativeLanguage") as? String {
            assistButton?.setTitle("\("Assist".localized()) \(nativeL.localized()) \("Learners".localized())", forState: .Normal)
        }

        
        if let practiseL = defaults.objectForKey("secondLanguage") as? String {
            let localizedPractise = "Practise".localized()
            practiseButton?.setTitle("\(localizedPractise) \(practiseL.localized())", forState: .Normal)
        }
        levelLabel?.setTitle("Level".localized() + levelValue!, forState: .Normal)
        storiesButton?.setTitle("Your Stories".localized(), forState: .Normal)
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        
        self.navigationController?.navigationBarHidden = true
        let defaults = NSUserDefaults.standardUserDefaults()
        var tk:String = ""
        if (defaults.objectForKey("token") != nil) {
            tk = defaults.objectForKey("token") as! String
        }
        
        print(tk)
        
        
        if (tk != "") {
            let request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/u/exp")!)
            request.HTTPMethod = "POST"
            let customAllowedSet =  NSCharacterSet(charactersInString:"+=\"#%/<>?@\\^`{|}").invertedSet
            let escapedString = tk.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
            let postString = "token="+escapedString!
            request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
            let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
                data, response, error in
                if error != nil {
                    print("error=\(error)")
                    return
                }
                let dataBack: String = NSString(data: data!, encoding: NSUTF8StringEncoding)! as String
                if(dataBack != ""){
                    dispatch_async(dispatch_get_main_queue()) {
                        print("done " + dataBack)
                        let exp: Int! = Int(dataBack)
                        let level: Int! = (exp/100) + 1
                        let floatLevel: Float! = Float(level)
                        let expLevel: Float! = Float(level * 100)
                        self.levelValue = " \(Int(floatLevel))"
                        self.setText()
                        self.expLabel?.setTitle("\(exp) / \(Int(expLevel)) exp", forState: .Normal)
                        let progress: Float! = 1 - ((expLevel - Float(exp))/100)
                        self.bar?.setProgress(progress, animated: false)
                    }
                }
                else{
                    dispatch_async(dispatch_get_main_queue()) {
                        print("error " + dataBack)
                    }
                }
            }
            task.resume()
        }
        self.setText()

    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.navigationBarHidden = false
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}