#import <UIKit/UIKit.h>
#import "DraggableSpeakingView.h"
#import <AVFoundation/AVFoundation.h>

@interface DraggableViewSpeakingBackground : UIView <DraggableViewSpeakingDelegate, UIAlertViewDelegate, AVAudioPlayerDelegate>

-(void)cardSwipedLeft:(UIView *)card;
-(void)cardSwipedRight:(UIView *)card;
-(void)loadCards;

@property (retain,nonatomic)NSMutableArray* soundData;
@property (retain,nonatomic)NSMutableArray* ids;
@property (retain,nonatomic)NSMutableArray* allCards;
@property (retain,nonatomic)NSString* titleText;
@property (retain,nonatomic)NSString* sumbitText;
@property (strong, nonatomic) AVAudioPlayer *audioPlayer;
@property (nonatomic,strong)UILabel* infoLabel;
@property (strong, nonatomic) NSTimer *secondsTimer;
@property (retain,nonatomic)NSString* infoText;
@property (retain,nonatomic)NSString* playText;
@property (retain,nonatomic)NSString* pauseText;
@property (retain,nonatomic)NSString* stopText;

@end
