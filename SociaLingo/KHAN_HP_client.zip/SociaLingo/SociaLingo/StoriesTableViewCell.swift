//
//  CommentTableViewCell.swift
//  SociaLingo
//
//  Created by Shaheem Khan on 2016-07-01.
//  Copyright © 2016 Shaheem Khan. All rights reserved.
//

import UIKit

class StoriesTableViewCell: UITableViewCell {

    @IBOutlet var textL: UILabel!
    @IBOutlet var scoreL: UILabel!
    @IBOutlet var agree: UILabel!
    @IBOutlet var disagree: UILabel!


    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
