//
//  AccountManagement.swift
//  SociaLingo
//
//  Created by Shaheem Khan on 2016-07-21.
//  Copyright © 2016 Shaheem Khan. All rights reserved.
//

import UIKit

class AccountManagement: UIViewController {
    
    @IBOutlet var signoutButton: UIButton?
    @IBOutlet var modButton: UIButton?

    override func viewDidLoad() {
        super.viewDidLoad()
        signoutButton?.setTitle("Sign Out".localized(), forState: .Normal)
        modButton?.setTitle("Apply to be a moderator".localized(), forState: .Normal)
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func mod() {
        let alert = UIAlertController(title: "Apply to be a moderator".localized(), message: "Enter e-mail address".localized(), preferredStyle: .Alert)
        
        alert.addTextFieldWithConfigurationHandler({ (textField) -> Void in
            textField.text = ""
        })
        
        alert.addAction(UIAlertAction(title: "Submit", style: .Default, handler: { (action) -> Void in
            let textField = alert.textFields![0] as UITextField
            let email: String! = textField.text
            
            let defaults = NSUserDefaults.standardUserDefaults()
            let tk: String = defaults.objectForKey("token") as! String
            
            var dataBack: String = "";
            let request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/u/mod")!)
            request.HTTPMethod = "POST"
            let customAllowedSet =  NSCharacterSet(charactersInString:"+=\"#%/<>?@\\^`{|}").invertedSet
            let escapedString = tk.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
            let postString = "token=\(escapedString!)&data=\(email)"
            request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
            let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
                data, response, error in
                if error != nil {
                    print("error=\(error)")
                    return
                }
                dataBack = NSString(data: data!, encoding: NSUTF8StringEncoding)! as String
                dispatch_async(dispatch_get_main_queue()) {
                    print("done \(dataBack)")
                }
            }
            task.resume()

            
            
            print("Text field: \(email)")
        }))
        
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    @IBAction func logOut() {
        
        let defaults = NSUserDefaults.standardUserDefaults()
        let tk: String = defaults.objectForKey("token") as! String
        
        var dataBack: String = "";
        let request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/u/logout")!)
        request.HTTPMethod = "POST"
        let customAllowedSet =  NSCharacterSet(charactersInString:"+=\"#%/<>?@\\^`{|}").invertedSet
        let escapedString = tk.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
        let postString = "token="+escapedString!
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            if error != nil {
                print("error=\(error)")
                return
            }
            dataBack = NSString(data: data!, encoding: NSUTF8StringEncoding)! as String
            if(dataBack == "LOGGED_OUT"){
                dispatch_async(dispatch_get_main_queue()) {
                    print("done " + dataBack)
                    defaults.setObject("", forKey: "token")
                    defaults.setObject("", forKey: "nativeLanguage")
                    defaults.setObject("", forKey: "secondLanguage")
                    defaults.setObject("", forKey: "username")
                    let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("InitialController") as! InitialController
                    self.navigationController?.pushViewController(secondViewController, animated: true)
                }
            }
            else {
                dispatch_async(dispatch_get_main_queue()) {
                    print("error " + dataBack)
                }
            }
        }
        task.resume()
        if (dataBack != "") {
            print("tes");
        }
    }
    
}