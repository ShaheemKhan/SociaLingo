#import <UIKit/UIKit.h>
#import "OverlayView.h"
#import <AVFoundation/AVFoundation.h>

@protocol DraggableWritingViewDelegate <NSObject>

-(void)cardSwipedLeft:(UIView *)card;
-(void)cardSwipedRight:(UIView *)card;

@end

@interface DraggableWritingView : UIView

@property (weak) id <DraggableWritingViewDelegate> delegate;
@property (nonatomic, strong)UIPanGestureRecognizer *panGestureRecognizer;
@property (nonatomic)CGPoint originalPoint;
@property (nonatomic,strong)OverlayView* overlayView;
@property (nonatomic,strong)UITextView* information;


-(void)leftClickAction;
-(void)rightClickAction;

@end
