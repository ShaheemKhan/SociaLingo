//
//  HelpWriting.swift
//  SociaLingo
//
//  Created by Shaheem Khan on 2016-06-04.
//  Copyright © 2016 Shaheem Khan. All rights reserved.
//

import UIKit
import AVFoundation

class HelpSpeaking: UIViewController, AVAudioPlayerDelegate, AVAudioRecorderDelegate {
    
    
    @IBOutlet var contentView: UIView?
    var audioPlayer: AVAudioPlayer!
    var soundFile: NSData!
    @IBOutlet var playButton: UIButton!
    @IBOutlet var oops: UILabel!
    var sound: NSData!
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var dataBack: String = "";
        let request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/s/retrieve")!)
        request.HTTPMethod = "POST"
        let defaults = NSUserDefaults.standardUserDefaults()
        let customAllowedSet =  NSCharacterSet(charactersInString:"+=\"#%/<>?@\\^`{|}").invertedSet
        let tk: String = defaults.objectForKey("token") as! String
        let escapedString = tk.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
        let lan: String = defaults.objectForKey("nativeLanguage") as! String
        let escapedString2 = lan.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
        let postString = "token=\(escapedString!)&data=\(escapedString2!)"
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            if error != nil {
                return
            }
            dataBack = NSString(data: data!, encoding: NSUTF8StringEncoding)! as String
            
            dispatch_async(dispatch_get_main_queue()) {
                let json: AnyObject? = dataBack.parseJSONString
                let jsonArr = json as! [[String: AnyObject]]
                if (json != nil && !jsonArr.isEmpty) {
                    print("Count \(jsonArr.count)")
                    let draggableBackground: DraggableViewSpeakingBackground = DraggableViewSpeakingBackground(frame: self.view.frame)
                    for temp in jsonArr {
                        let id = (temp as NSDictionary)["speakingPK"] as! String
                        draggableBackground.ids.addObject(id)
                        
                        var dataBack: String = "";
                        let request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/s/retrieve/sound")!)
                        request.HTTPMethod = "POST"
                        let customAllowedSet =  NSCharacterSet(charactersInString:"+=\"#%/<>?@\\^`{|}").invertedSet
                        let escapedString2 = id.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
                        let postString = "id=\(escapedString2!)"
                        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
                        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
                            data, response, error in
                            if error != nil {
                                print("error=\(error)")
                                return
                            }
                            dataBack = NSString(data: data!, encoding: NSUTF8StringEncoding)! as String
                            dispatch_async(dispatch_get_main_queue()) {
                                let soundData: NSData! = NSData(base64EncodedString: dataBack, options:   NSDataBase64DecodingOptions(rawValue: 0))
                                draggableBackground.soundData.addObject(soundData)
                            }
                        }
                        task.resume()
                        
                    }
                    draggableBackground.playText = "Play".localized()
                    draggableBackground.pauseText = "Pause".localized()
                    draggableBackground.stopText = "Stop".localized()

                    draggableBackground.titleText = "Comments".localized()
                    draggableBackground.sumbitText = "Submit".localized()
                    draggableBackground.infoText = "Out of Cards".localized()
                    draggableBackground.backgroundColor  = UIColor(red: 75.0/255.0, green: 45.0/255.0, blue: 116.0/255.0, alpha: 1.0)
                    self.contentView!.addSubview(draggableBackground)
                    self.automaticallyAdjustsScrollViewInsets = false
                    draggableBackground.loadCards()

                }
                
            }
            
        }
        task.resume()
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}
