//
//  SignIn.swift
//  SociaLingo
//
//  Created by Shaheem Khan on 2016-05-17.
//  Copyright © 2016 Shaheem Khan. All rights reserved.
//

import UIKit
import Localize_Swift

class SignUp: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var username: UITextField!
    @IBOutlet var password: UITextField!
    @IBOutlet var repassword: UITextField!
    @IBOutlet var nativeButton: UIButton!
    @IBOutlet var secondButton: UIButton!
    @IBOutlet var usernameLabel: UILabel!
    @IBOutlet var passwordLabel: UILabel!
    @IBOutlet var reenterPasswordLabel: UILabel!
    @IBOutlet var register: UIButton!
    var stringTimer: NSTimer!
    
    var actionSheet: UIAlertController!
    let availableLanguages = Localize.availableLanguages()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        reenterPasswordLabel.font = reenterPasswordLabel.font.fontWithSize(14)
        nativeButton.titleLabel?.font = nativeButton.titleLabel?.font.fontWithSize(13)
        secondButton.titleLabel?.font = secondButton.titleLabel?.font.fontWithSize(13)
        
        password.secureTextEntry = true
        repassword.secureTextEntry = true
        username.delegate = self
        password.delegate = self
        repassword.delegate = self
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.setText), name: LCLLanguageChangeNotification, object: nil)
        self.stringTimer = NSTimer.scheduledTimerWithTimeInterval(3.0, target: self, selector: #selector(self.onTick), userInfo: nil, repeats: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(animated: Bool) {
    }
    
    func setText() {
        password?.secureTextEntry = true
        usernameLabel.setTitleWithOutAnimation("User ID".localized())
        passwordLabel.setTitleWithOutAnimation("Password".localized())
        
        if (nativeButton.titleLabel?.text == "Select a language you know"
            || nativeButton.titleLabel?.text == "Sélectionnez une langue que vous connaissez") {
            nativeButton.setTitleWithOutAnimation("Select a language you know".localized())
        }
        if (secondButton.titleLabel?.text == "What language would you like to practice?"
            || secondButton.titleLabel?.text == "Quelle langue voulez-vous pratiquer?") {
            secondButton.setTitleWithOutAnimation("What language would you like to practice?".localized())
        }
        reenterPasswordLabel.setTitleWithOutAnimation("Confirm Password".localized())
        register.setTitleWithOutAnimation("Register".localized())
        navigationItem.title = "Sign Up".localized()
    }
    
    func onTick() {
        if (Localize.currentLanguage() as String! == "en") {
            Localize.setCurrentLanguage("fr")
        }
        else if (Localize.currentLanguage() as String! == "fr") {
            Localize.setCurrentLanguage("en")
        }
    }
    
    
    @IBAction func nativeLanguageSelection() {
        Localize.setCurrentLanguage(Localize.defaultLanguage())
        actionSheet = UIAlertController(title: nil, message: "Switch Language", preferredStyle: UIAlertControllerStyle.ActionSheet)
        for language in availableLanguages {
            let temp = Localize.displayNameForLanguage(language)
            let displayName = Config.getDisplayName(temp)
            let languageAction = UIAlertAction(title: displayName, style: .Default, handler: {
                (alert: UIAlertAction!) -> Void in
                self.stringTimer.invalidate()
                Localize.setCurrentLanguage(language)
                self.nativeButton.setTitle(displayName, forState: .Normal)
            })
            if (displayName != "") {
                actionSheet.addAction(languageAction)
            }
        }
        if (UIDevice.currentDevice().userInterfaceIdiom == .Pad) {
            actionSheet.popoverPresentationController!.sourceView = self.view
        }
        self.presentViewController(actionSheet, animated: true, completion: nil)
    }
    
    func textFieldShouldReturn(textField: UITextField!) -> Bool {
        textField.resignFirstResponder()
        return true;
    }
    
    @IBAction func secondLanguageSelection() {
        actionSheet = UIAlertController(title: nil, message: "Switch Language", preferredStyle: UIAlertControllerStyle.ActionSheet)
        for language in availableLanguages {
            let temp = Localize.displayNameForLanguage(language)
            let displayName = Config.getDisplayName(temp)
            print("Display name \(displayName) Language \(language)")
            let languageAction = UIAlertAction(title: displayName, style: .Default, handler: {
                (alert: UIAlertAction!) -> Void in
                self.secondButton!.setTitle(displayName, forState: .Normal)
            })
            if (displayName != "") {
                actionSheet.addAction(languageAction)
            }
        }
        if (UIDevice.currentDevice().userInterfaceIdiom == .Pad) {
            actionSheet.popoverPresentationController!.sourceView = self.view
        }
        self.presentViewController(actionSheet, animated: true, completion: nil)
    }
    
    @IBAction func signUp() {
        if (username.text != "" && password.text != ""
            && nativeButton.titleLabel?.text != "Select a language you know"
            && nativeButton.titleLabel?.text != "Sélectionnez une langue que vous connaissez"
            && secondButton.titleLabel?.text != "What language would you like to practice?"
            && secondButton.titleLabel?.text != "Quelle langue voulez-vous pratiquer?"
            && repassword.text == password.text){
            var dataBack: String = "";
            let defaults = NSUserDefaults.standardUserDefaults()
            let request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/u/register")!)
            request.HTTPMethod = "POST"
            let user : String! = username!.text
            let pass : String! = password!.text
            let lan1 : String! = nativeButton!.titleLabel!.text!
            let lan2 : String! = secondButton!.titleLabel!.text!
            print("Pass \(pass)")
            let enc = try! ("\(pass)").aesEncrypt(Config.key())
            let customAllowedSet =  NSCharacterSet(charactersInString:"+=\"#%/<>?@\\^`{|}").invertedSet
            let escapedString = enc.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
            let postString = "id=\(user)&pass=\(escapedString)&native=\(lan1)&second=\(lan2)"
            print(postString)
            request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
            let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
                data, response, error in
                if error != nil {
                    print("error=\(error)")
                    return
                }
                dataBack = NSString(data: data!, encoding: NSUTF8StringEncoding)! as String
                if(dataBack != "ID_NOT_UNIQUE"){
                    dispatch_async(dispatch_get_main_queue()) {
                        print("done " + dataBack)
                        let dataBackA = dataBack.characters.split{$0 == "_"}.map(String.init)
                        defaults.setObject(dataBackA[0], forKey: "token")
                        defaults.setObject(dataBackA[1], forKey: "nativeLanguage")
                        defaults.setObject(dataBackA[2], forKey: "secondLanguage")
                        defaults.setObject(user, forKey: "username")
                        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("WelcomePage") as! WelcomePage
                        self.navigationController?.pushViewController(secondViewController, animated: true)
                    }
                }
                else {
                    dispatch_async(dispatch_get_main_queue()) {
                        print("error " + dataBack)
                    }
                }
            }
            task.resume()
            if (dataBack != "") {
                print("tes");
            }
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
       self.stringTimer.invalidate()
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
}