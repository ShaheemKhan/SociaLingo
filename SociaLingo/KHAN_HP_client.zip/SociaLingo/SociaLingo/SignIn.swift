//
//  SignIn.swift
//  SociaLingo
//
//  Created by Shaheem Khan on 2016-05-17.
//  Copyright © 2016 Shaheem Khan. All rights reserved.
//

import UIKit
import Localize_Swift

class SignIn: UIViewController {
    
    @IBOutlet var username: UITextField?
    @IBOutlet var password: UITextField?
    @IBOutlet var usernameLabel: UILabel!
    @IBOutlet var passwordLabel: UILabel!
    @IBOutlet var submit: UIButton!
    var timer: NSTimer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setText()
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.setText), name: LCLLanguageChangeNotification, object: nil)
        timer = NSTimer.scheduledTimerWithTimeInterval(3.0, target: self, selector: #selector(self.onTick), userInfo: nil, repeats: true)
    }
    
    
    override func viewDidDisappear(animated: Bool) {
        timer.invalidate()
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    func setText() {
        password?.secureTextEntry = true
        usernameLabel.setTitleWithOutAnimation("User ID".localized())
        passwordLabel.setTitleWithOutAnimation("Password".localized())
        submit.setTitleWithOutAnimation("Submit".localized())
        navigationItem.title = "Sign In".localized()
    }
    
    func onTick() {
        if (Localize.currentLanguage() as String! == "en") {
            Localize.setCurrentLanguage("fr")
        }
        else if (Localize.currentLanguage() as String! == "fr") {
            Localize.setCurrentLanguage("en")
        }
    }
    
    
    @IBAction func signIn() {
        timer.invalidate()
        if (username?.text != "" && password?.text != "") {
            let request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/u/login")!)
            request.HTTPMethod = "POST"
            let user: String! = username!.text
            let pass: String! = password!.text
            let enc = try! (pass).aesEncrypt(Config.key())
            let customAllowedSet =  NSCharacterSet(charactersInString:"+=\"#%/<>?@\\^`{|}").invertedSet
            let escapedString = enc.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
            let postString = "id=\(user)&pass=\(escapedString)"
            request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
            let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
                data, response, error in
                if error != nil {
                    print("error=\(error)")
                    return
                }
                let dataBack: String = NSString(data: data!, encoding: NSUTF8StringEncoding)! as String
                if(dataBack != "INVALID_CREDENTIALS"){
                    dispatch_async(dispatch_get_main_queue()) {
                        print("done " + dataBack)
                        let defaults = NSUserDefaults.standardUserDefaults()
                        let dataBackA = dataBack.characters.split{$0 == "_"}.map(String.init)
                        
                        defaults.setObject(dataBackA[0], forKey: "token")
                        defaults.setObject(dataBackA[1], forKey: "nativeLanguage")
                        defaults.setObject(dataBackA[2], forKey: "secondLanguage")
                        Localize.setCurrentLanguage(Config.getCode(dataBackA[1]))
                        defaults.setObject(user, forKey: "username")
                        
                        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("WelcomePage") as! WelcomePage
                        self.navigationController?.pushViewController(secondViewController, animated: true)
                    }
                }
                else{
                    dispatch_async(dispatch_get_main_queue()) {
                        print("error " + dataBack)
                    }
                }
            }
            task.resume()
        }
    }
    
}