//
//  HelpWriting.swift
//  SociaLingo
//
//  Created by Shaheem Khan on 2016-06-04.
//  Copyright © 2016 Shaheem Khan. All rights reserved.
//

import UIKit

class HelpWriting: UIViewController {
    
    @IBOutlet var contentView: UIView?
    @IBOutlet var oops: UILabel?

    override func viewDidLoad() {
        super.viewDidLoad()
        var dataBack: String = "";
        let request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/w/retrieve")!)
        request.HTTPMethod = "POST"
        let defaults = NSUserDefaults.standardUserDefaults()
        let customAllowedSet =  NSCharacterSet(charactersInString:"+=\"#%/<>?@\\^`{|}").invertedSet
        let tk: String = defaults.objectForKey("token") as! String
        let escapedString = tk.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
        let lan: String = defaults.objectForKey("nativeLanguage") as! String
        let escapedString2 = lan.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
        let postString = "token="+escapedString!+"_"+escapedString2!
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            if error != nil {
                //print("error=\(error)")
                return
            }
            dataBack = NSString(data: data!, encoding: NSUTF8StringEncoding)! as String
            
            dispatch_async(dispatch_get_main_queue()) {                
                let json: AnyObject? = dataBack.parseJSONString
                let jsonArr = json as! [[String: AnyObject]]
                if (json != nil && !jsonArr.isEmpty) {
                    print("Count \(jsonArr.count)")
                    self.oops?.hidden = true
                    let draggableBackground: DraggableViewWritingBackground = DraggableViewWritingBackground(frame: self.view.frame)
                    for temp in jsonArr {
                        let name = (temp as NSDictionary)["data"] as! String
                        let id = (temp as NSDictionary)["writingPK"] as! String
                        draggableBackground.ids.addObject(id)
                        draggableBackground.exampleCardLabels.addObject(name)
                    }
                    draggableBackground.loadCards()
                    draggableBackground.titleText = "Comments".localized()
                    draggableBackground.sumbitText = "Submit".localized()
                    draggableBackground.infoText = "Out of Cards".localized()
                    draggableBackground.backgroundColor  = UIColor(red: 75.0/255.0, green: 45.0/255.0, blue: 116.0/255.0, alpha: 1.0)
                    self.contentView!.addSubview(draggableBackground)
                    self.automaticallyAdjustsScrollViewInsets = false
                }
                
            }
            
        }
        task.resume()

    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}
