#import <UIKit/UIKit.h>
#import "OverlayView.h"

@protocol DraggableViewSpeakingDelegate <NSObject>

-(void)cardSwipedLeft:(UIView *)card;
-(void)cardSwipedRight:(UIView *)card;

@end

@interface DraggableSpeakingView : UIView

@property (weak) id <DraggableViewSpeakingDelegate> delegate;
@property (nonatomic, strong)UIPanGestureRecognizer *panGestureRecognizer;
@property (nonatomic)CGPoint originalPoint;
@property (nonatomic,strong)OverlayView* overlayView;
@property (nonatomic,strong)UIButton* playButton;
@property (nonatomic,strong)UIButton* pauseButton;
@property (nonatomic,strong)UIButton* stopButton;
@property (nonatomic,strong)UIProgressView* bar;
@property (nonatomic,strong)UILabel* timeLabel;
@property (nonatomic,strong)UILabel* swipeLabel;
@property (retain,nonatomic)NSString* playText;
@property (retain,nonatomic)NSString* pauseText;
@property (retain,nonatomic)NSString* stopText;

-(void)leftClickAction;
-(void)rightClickAction;
-(void) setTitles:(NSString *)stopText: (NSString*)pauseText: (NSString*)playText;

@end
