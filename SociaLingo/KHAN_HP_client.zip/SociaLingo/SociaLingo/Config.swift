//
//  Config.swift
//  SociaLingo
//
//  Created by Shaheem Khan on 2016-06-07.
//  Copyright © 2016 Shaheem Khan. All rights reserved.
//

import Foundation

let ipAddress = "192.168.1.21"
let secretKey = "TheBestSecretKey"

@objc class Config: NSObject {
    private override init() {}
    
    class func ip() -> String { return ipAddress }
    class func key() -> String { return secretKey }
    
    class func getCode(text: String) -> String {
        if (text.lowercaseString == "English".lowercaseString) {
            return "en"
        }
        else if (text.lowercaseString == "French".lowercaseString) {
            return "fr"
        }
        else if (text.lowercaseString == "Anglais".lowercaseString) {
            return "en"
        }
        else if (text.lowercaseString == "Français".lowercaseString) {
            return "fr"
        }
        else {
            return ""
        }
    }
    
    class func getDisplayName(text: String) -> String {
        if (text.lowercaseString == "English".lowercaseString) {
            return "English/Anglais"
        }
        else if (text.lowercaseString == "French".lowercaseString) {
            return "French/Français"
        }
        else if (text.lowercaseString == "Anglais".lowercaseString) {
            return "English/Anglais"
        }
        else if (text.lowercaseString == "Français".lowercaseString) {
            return "French/Français"
        }
        else {
            return ""
        }
    }

}

extension UIButton {
    func setTitleWithOutAnimation(title: String?) {
        UIView.setAnimationsEnabled(false)
        
        setTitle(title, forState: .Normal)
        
        layoutIfNeeded()
        UIView.setAnimationsEnabled(true)
    }
}

extension UILabel {
    func setTitleWithOutAnimation(title: String?) {
        UIView.setAnimationsEnabled(false)
        
        self.text = title
        layoutIfNeeded()
        UIView.setAnimationsEnabled(true)
    }
}