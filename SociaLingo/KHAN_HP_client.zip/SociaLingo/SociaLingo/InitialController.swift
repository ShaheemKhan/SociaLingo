//
//  ViewController.swift
//  SociaLingo
//
//  Created by Shaheem Khan on 2016-05-06.
//  Copyright © 2016 Shaheem Khan. All rights reserved.
//

import UIKit
import Security
import Localize_Swift

class InitialController: UIViewController {
    
    var timer: NSTimer!
    @IBOutlet var signInButton: UIButton!
    @IBOutlet var joinButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.setText), name: LCLLanguageChangeNotification, object: nil)
        Localize.resetCurrentLanguageToDefault()
        self.setText()
        timer = NSTimer.scheduledTimerWithTimeInterval(3.0, target: self, selector: #selector(self.onTick), userInfo: nil, repeats: true)
        
        self.navigationController?.navigationBarHidden = true
        
        let defaults = NSUserDefaults.standardUserDefaults()
        if (defaults.objectForKey("token") != nil) {
            let tk:String! = defaults.objectForKey("token") as! String
            
            if (tk != "") {
                let request = NSMutableURLRequest(URL: NSURL(string: "http://" + Config.ip() + ":8080/restful/rest/u/check")!)
                request.HTTPMethod = "POST"
                let customAllowedSet =  NSCharacterSet(charactersInString:"+=\"#%/<>?@\\^`{|}").invertedSet
                let escapedString = tk.stringByAddingPercentEncodingWithAllowedCharacters(customAllowedSet)
                let postString = "token="+escapedString!
                request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
                let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
                    data, response, error in
                    if error != nil {
                        print("error=\(error)")
                        return
                    }
                    let dataBack: String = NSString(data: data!, encoding: NSUTF8StringEncoding)! as String
                    if(dataBack == "TRUE"){
                        dispatch_async(dispatch_get_main_queue()) {
                            print("done " + dataBack)
                            let defaults = NSUserDefaults.standardUserDefaults()
                            if let nativeL = defaults.objectForKey("nativeLanguage") as? String {
                                Localize.setCurrentLanguage(Config.getCode(nativeL))
                                print("lan \(nativeL)")
                            }
                            let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("WelcomePage") as! WelcomePage
                            self.navigationController?.pushViewController(secondViewController, animated: true)
                        }
                    }
                    else{
                        dispatch_async(dispatch_get_main_queue()) {
                            print("error " + dataBack)
                        }
                    }
                }
                task.resume()
                
            }
        }
    }
    
    func setText() {
        signInButton.setTitleWithOutAnimation("Sign In".localized())
        joinButton.setTitleWithOutAnimation("Join SociaLingo".localized())
    }
    
    func onTick() {
        if (Localize.currentLanguage() as String! == "en") {
            Localize.setCurrentLanguage("fr")
        }
        else if (Localize.currentLanguage() as String! == "fr") {
            Localize.setCurrentLanguage("en")
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBarHidden = true
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.navigationBarHidden = false
        self.timer.invalidate()
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

