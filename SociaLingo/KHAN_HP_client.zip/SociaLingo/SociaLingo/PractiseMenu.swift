//
//  Comments.swift
//  SociaLingo
//
//  Created by Shaheem Khan on 2016-06-26.
//  Copyright © 2016 Shaheem Khan. All rights reserved.
//


import UIKit
import Localize_Swift


class PractiseMenu: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var tableView: UITableView!
    var tableData: [String] = []
    @IBOutlet var option: UISegmentedControl!

    
    override func viewDidLoad() {
        self.tableData.append("Writing".localized())
        self.tableData.append("Speaking".localized())
        self.tableView.reloadData()
        self.tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "myCell")
        self.tableView.backgroundColor = UIColor(red: 75.0/255.0, green: 45.0/255.0, blue: 116.0/255.0, alpha: 1.0)
        self.tableView.separatorStyle = .None
        self.title = "Practise".localized()
        option.setTitle("Practise".localized(), forSegmentAtIndex: 0)
        option.setTitle("Assist".localized(), forSegmentAtIndex: 1)
        let titleTextAttributes = [NSForegroundColorAttributeName: UIColor.whiteColor()]
        UISegmentedControl.appearance().setTitleTextAttributes(titleTextAttributes, forState: .Selected)
        super.viewDidLoad()
    }
    
    override func viewDidAppear(animated: Bool) {
        print("test")
        self.tableView.reloadData()
        super.viewDidAppear(animated)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.tableData.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell: UITableViewCell = tableView.dequeueReusableCellWithIdentifier("myCell")!
        cell.textLabel?.text = self.tableData[indexPath.row]
        cell.textLabel?.textColor = UIColor.whiteColor()
        cell.backgroundColor = self.view.backgroundColor
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("Row \(indexPath.row) selected")
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        if (self.title == "Assist".localized()) {
            if indexPath.row == 0 {
                let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("HelpWriting") as! HelpWriting
                self.navigationController?.pushViewController(secondViewController, animated: true)
            }
            if indexPath.row == 1 {
                let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("HelpSpeaking") as! HelpSpeaking
                self.navigationController?.pushViewController(secondViewController, animated: true)
            }
        }
        else {
            if indexPath.row == 0 {
                let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("PractiseWriting") as! PractiseWriting
                self.navigationController?.pushViewController(secondViewController, animated: true)
            }
            if indexPath.row == 1 {
                let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("PractiseSpeaking") as! PractiseSpeaking
                self.navigationController?.pushViewController(secondViewController, animated: true)
            }
         }
    }
    
    @IBAction func indexChanged(sender:UISegmentedControl) {
        switch option.selectedSegmentIndex {
            case 0:
                self.title = "Practise".localized()
            case 1:
                self.title = "Assist".localized()
            default:
                break;
        }
    }

 
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}

