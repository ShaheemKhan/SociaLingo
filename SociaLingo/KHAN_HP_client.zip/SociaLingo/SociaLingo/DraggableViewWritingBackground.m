#import "DraggableViewWritingBackground.h"
#import "SociaLingo-Swift.h"


@implementation  DraggableViewWritingBackground{
    NSInteger cardsLoadedIndex;
    NSMutableArray *loadedCards;
}

static int MAX_BUFFER_SIZE = 2;
static int CARD_HEIGHT = 450;
static int CARD_WIDTH = 290;
static int voteType = 1;

@synthesize exampleCardLabels;
@synthesize allCards;
@synthesize ids, titleText, sumbitText, infoLabel, infoText;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [super layoutSubviews];
        
        CGRect screenRect = [[UIScreen mainScreen] bounds];
        CARD_HEIGHT = screenRect.size.height - 96;
        CARD_WIDTH =  screenRect.size.width - 32;
        exampleCardLabels = [NSMutableArray new];
        loadedCards = [[NSMutableArray alloc] init];
        allCards = [[NSMutableArray alloc] init];
        ids = [[NSMutableArray alloc] init];
        cardsLoadedIndex = 0;
        [self loadCards];
    }
    return self;
}

-(void)setupView {

}

-( DraggableWritingView *)createDraggableViewWithDataAtIndex:(NSInteger)index
{
     DraggableWritingView *draggableView = [[ DraggableWritingView alloc]initWithFrame:CGRectMake(16, 80, CARD_WIDTH, CARD_HEIGHT)];
    draggableView.information.text = [exampleCardLabels objectAtIndex:index];
    draggableView.information.backgroundColor = [UIColor colorWithRed:142.0/255.0 green:119.0/255.0 blue:173.0/255.0 alpha:1.0];
    draggableView.information.textColor = [UIColor whiteColor];
    
    [draggableView.information setFont:[UIFont systemFontOfSize:15]];
    draggableView.delegate = self;
    

    return draggableView;
}

-(void)loadCards
{
    if([exampleCardLabels count] > 0) {
        NSInteger numLoadedCardsCap =(([exampleCardLabels count] > MAX_BUFFER_SIZE)?MAX_BUFFER_SIZE:[exampleCardLabels count]);
        //%%% if the buffer size is greater than the data size, there will be an array error, so this makes sure that doesn't happen
        
        //%%% loops through the exampleCardsLabels array to create a card for each label.  This should be customized by removing "exampleCardLabels" with your own array of data
        for (int i = 0; i<[exampleCardLabels count]; i++) {
             DraggableWritingView* newCard = [self createDraggableViewWithDataAtIndex:i];
            [allCards addObject:newCard];
            
            if (i<numLoadedCardsCap) {
                //%%% adds a small number of cards to be loaded
                [loadedCards addObject:newCard];
            }
        }
        
        //%%% displays the small number of loaded cards dictated by MAX_BUFFER_SIZE so that not all the cards
        // are showing at once and clogging a ton of data
        for (int i = 0; i<[loadedCards count]; i++) {
            if (i>0) {
                [self insertSubview:[loadedCards objectAtIndex:i] belowSubview:[loadedCards objectAtIndex:i-1]];
            } else {
                [self addSubview:[loadedCards objectAtIndex:i]];
            }
            cardsLoadedIndex++; //%%% we loaded a card into loaded cards, so we have to increment
        }
    }
}

-(void)cardSwipedLeft:(UIView *)card {
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:titleText
                                                    message:@""
                                                   delegate:self
                                          cancelButtonTitle:sumbitText
                                          otherButtonTitles:nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    [alert show];
    
    voteType = -1;
}

-(void)cardSwipedRight:(UIView *)card {
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:titleText
                                                    message:@""
                                                   delegate:self
                                          cancelButtonTitle:sumbitText
                                          otherButtonTitles:nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    [alert show];
    
    voteType = 1;
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSString *ip;
    if (voteType == 1) {
        ip = [NSString stringWithFormat: @"http://%@:8080/restful/rest/w/upvote", [Config ip] ];
    }
    else {
        ip = [NSString stringWithFormat:@"http://%@:8080/restful/rest/w/downvote", [Config ip] ];
    }
    NSURL *url = [NSURL URLWithString: ip];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setHTTPMethod:@"POST"];
    [request setURL:url];
    NSCharacterSet *customAllowedSet = [NSCharacterSet characterSetWithCharactersInString:@"+=\"#%/<>?@\\^`{|}"].invertedSet;
    NSString *token = [[NSUserDefaults standardUserDefaults] objectForKey: @"token"];
    NSString *wID =  [ids objectAtIndex:0];
    
    NSString *postString = [NSString stringWithFormat:@"id=%@&token=%@&data=%@", [wID stringByAddingPercentEncodingWithAllowedCharacters:customAllowedSet], [token stringByAddingPercentEncodingWithAllowedCharacters:customAllowedSet],[alertView textFieldAtIndex:0].text ];
    request.HTTPBody = [postString dataUsingEncoding:NSUTF8StringEncoding];
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithRequest:request
                completionHandler:^(NSData *data,
                                    NSURLResponse *response,
                                    NSError *error) {
                    NSLog(@"ids %@", [[NSString alloc] initWithData: data encoding:NSASCIIStringEncoding]);
                    [ids removeObjectAtIndex:0];
                }] resume];
    
    
    
    [loadedCards removeObjectAtIndex:0]; //%%% card was swiped, so it's no longer a "loaded card"
    if (cardsLoadedIndex < [allCards count]) { //%%% if we haven't reached the end of all cards, put another into the loaded cards
        [loadedCards addObject:[allCards objectAtIndex:cardsLoadedIndex]];
        cardsLoadedIndex++;//%%% loaded a card, so have to increment count
        [self insertSubview:[loadedCards objectAtIndex:(MAX_BUFFER_SIZE-1)] belowSubview:[loadedCards objectAtIndex:(MAX_BUFFER_SIZE-2)]];
    }
    int icount = [ids count];
    NSLog(@"%d", icount);
    if (icount == 1) { //%%% if we haven't reached the end of all cards, put another into the loaded cards
        infoLabel = [[UILabel alloc] init];
        infoLabel.text = infoText;
        infoLabel.textColor = [UIColor whiteColor];
        infoLabel.textAlignment = NSTextAlignmentCenter;
        CGFloat height = [UIScreen mainScreen].bounds.size.height;
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        infoLabel.frame = CGRectMake(((width-210.0)/2), ((height-20.0)/2),210,20);
        [self addSubview:infoLabel];
    }

}


@end