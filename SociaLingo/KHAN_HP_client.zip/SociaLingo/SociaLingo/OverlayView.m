#import "OverlayView.h"

@implementation OverlayView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

-(void)setMode:(GGOverlayViewMode)mode {
    if (_mode == mode) {
        return;
    }
    _mode = mode;
}

-(void)layoutSubviews {
    [super layoutSubviews];
}

@end
