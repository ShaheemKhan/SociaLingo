//
//  Bridging.h
//  CryptoSwift
//
//  Created by Marcin Krzyzanowski on 04/02/15.
//  Copyright (c) 2015 Marcin Krzyzanowski. All rights reserved.
//

#ifndef CryptoSwift_Bridging_h
#define CryptoSwift_Bridging_h

#import <CommonCrypto/CommonCrypto.h>

#endif
